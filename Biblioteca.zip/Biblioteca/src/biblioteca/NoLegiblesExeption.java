
package biblioteca;

public class NoLegiblesExeption extends RuntimeException{

    public NoLegiblesExeption(String message) {
        super(message);
    }
    
    
}
