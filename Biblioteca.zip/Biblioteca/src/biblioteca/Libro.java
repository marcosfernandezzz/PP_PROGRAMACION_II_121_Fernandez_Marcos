package biblioteca;

public class Libro extends Publicacion implements Legible {

    private String autor;
    private Genero genero;

    public Libro(String autor, Genero genero, String titulo, int anioPublicacion) {
        super(titulo, anioPublicacion);
        this.autor = autor;
        this.genero = genero;
    }

    @Override
    public void leer() {
        System.out.println("Comenzando a leer el libro: " + getTitulo() + " por " + autor);
    }

    @Override
    public String toString() {
        return "Libro [autor=" + autor + ", genero= " + genero + "]";
    }

}
