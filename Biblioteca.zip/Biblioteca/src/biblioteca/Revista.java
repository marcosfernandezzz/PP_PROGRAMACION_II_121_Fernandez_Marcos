package biblioteca;

public class Revista extends Publicacion implements Legible {

    private int numeroEdicion;

    public Revista(int numeroEdicion, String titulo, int añoPublicacion) {
        super(titulo, añoPublicacion);
        this.numeroEdicion = numeroEdicion;
    }

    @Override
    public void leer() {
        System.out.println("Comenzando a leer el libro: " + getTitulo() + " edicion " + numeroEdicion);
    }

    @Override
    public String toString() {
        return "Revista [" + "numeroEdicion=" + numeroEdicion + ']';
    }

}
