package biblioteca;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Biblioteca {

    private List<Publicacion> publicaciones;

    public Biblioteca() {
        publicaciones = new ArrayList<>();
    }

    public void agregarPublicacion(Publicacion publicacion) {
        if (publicacion == null) {
            throw new NullPointerException("La publicacion no puede ser nula.");
        }

        // Verificar si la publicación ya existe
        for (Publicacion publi : publicaciones) {
            if (publi.getTitulo().equals(publicacion.getTitulo()) && publi.getAnioPublicacion() == publicacion.getAnioPublicacion()) {
                throw new PublicacionExistenteException("La publicacion ya se encuentra en la biblioteca.");
            }
        }

        // Si no existe, se agrega la publicación
        publicaciones.add(publicacion);
    }

    public void mostrarPublicaciones() {
        if (publicaciones.size() == 0) {
            System.out.println("No hay publicaciones en la biblioteca.");
        } else { //Mientras que la lista no este vacia,se muestran las publicaciones
            for (Publicacion pub : publicaciones) {
                System.out.println("Titulo: " + pub.getTitulo() + ", Anioo: " + pub.getAnioPublicacion());
            }
        }
    }

    public void leerPublicaciones() {
        boolean legibles = false;

        for (Publicacion publi : publicaciones) {
            if (publi instanceof Libro) {
                legibles = true; // Solo se establece en true para libros
                ((Libro) publi).leer();
            } else if (publi instanceof Revista) {
                legibles = true; // Solo se establece en true para revistas
                ((Revista) publi).leer();
            } else if (publi instanceof Ilustracion) {
                System.out.println("Ilustracion, no se puede leer.");
                // No se hace nada más, no se afecta 'legibles'
            }
        }

        // Después de recorrer todas las publicaciones, verificamos si se han leído
        if (!legibles) {
            throw new NoLegiblesExeption("No hay ninguna publicacion legible.");
        }
    }

    @Override
    public String toString() {
        return "Biblioteca{" + "publicaciones=" + publicaciones + '}';
    }

}
