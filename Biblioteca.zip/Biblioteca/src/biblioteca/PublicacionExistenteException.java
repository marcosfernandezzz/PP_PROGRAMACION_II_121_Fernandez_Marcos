
package biblioteca;

public class PublicacionExistenteException extends RuntimeException{

    public PublicacionExistenteException(String message) {
        super(message);
    }
    
    
}
