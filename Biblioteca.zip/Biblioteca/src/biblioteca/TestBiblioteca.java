
package biblioteca;

public class TestBiblioteca {

    public static void main(String[] args) {
        Biblioteca biblioteca = new Biblioteca();
        
        try{
            biblioteca.agregarPublicacion(new Libro("C. S. Lewis", Genero.FICCION, "Narnia", 1950));
            biblioteca.agregarPublicacion(new Libro("Gabriel Garcia Marquez", Genero.FICCION, "Cien anios de soledad", 1967));
            biblioteca.agregarPublicacion(new Libro("Stephen Hawking", Genero.NO_FICCION, "Breve historia del tiempo", 1988));

            biblioteca.agregarPublicacion(new Revista(345, "Revista Nature", 2022));
            biblioteca.agregarPublicacion(new Revista(128, "National Geographic", 2021));
            biblioteca.agregarPublicacion(new Revista(75, "Scientific American", 2023));

            biblioteca.agregarPublicacion(new Ilustracion("Quinquela Martin", 125, 105, "La vida en el puerto", 1950));
            biblioteca.agregarPublicacion(new Ilustracion("Pablo Picasso", 200, 150, "Guernica", 1937));
            biblioteca.agregarPublicacion(new Ilustracion("Frida Kahlo", 80, 120, "Autorretrato con collar de espinas", 1940));

            biblioteca.mostrarPublicaciones();
            System.out.println("");
            biblioteca.leerPublicaciones();
        }    
        catch (PublicacionExistenteException e) {
            System.out.println("Error de repeticion: " + e.getMessage());  //
        }       
        catch (NoLegiblesExeption e) {
            System.out.println("Error de legibilidad: " + e.getMessage());
        } 
        catch (NullPointerException e) {
            System.out.println("Error de inexistencia: se quiso agregar una publicación nula");
        }
        
    }
    
}
