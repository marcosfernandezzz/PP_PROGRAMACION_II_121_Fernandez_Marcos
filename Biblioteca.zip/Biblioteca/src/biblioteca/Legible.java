
package biblioteca;

public interface Legible {
    
    
    public void leer();
    
}
